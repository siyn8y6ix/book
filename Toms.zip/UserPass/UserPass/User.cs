﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserPass
{
    public partial class frmUser : Form
    {
        OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TOMMY\OneDrive\VS\FINAL\USERLIBSYS-main\UserPass\PASSWORD.mdb");
        OleDbCommand command = new OleDbCommand();
        DataView dv = new DataView();
        OleDbDataAdapter adapter = new OleDbDataAdapter();
        DataTable table = new DataTable();
        
        public frmUser()
        {
            InitializeComponent();
            loadDatagrid();
            connection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TOMMY\OneDrive\VS\FINAL\USERLIBSYS-main\UserPass\PASSWORD.mdb");
        }

        public void loadDatagrid()
        {
            connection.Open();
            table = new DataTable();
            adapter = new OleDbDataAdapter("Select * from [Password]", connection);
            adapter.Fill(table);
            grid1.DataSource = table;
            connection.Close();


        }

        private void grid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow select = grid1.Rows[e.RowIndex];
            string number = select.Cells["Username"].Value.ToString();
            string tile = select.Cells["Password"].Value.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtusername.Text))
            {
                MessageBox.Show("Username field must not be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (string.IsNullOrEmpty(txtpassword.Text))
            {
                MessageBox.Show("Password field must not be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                string con = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TOMMY\OneDrive\VS\FINAL\USERLIBSYS-main\UserPass\PASSWORD.mdb; Persist Security Info = False; ";
                connection = new OleDbConnection(con);
                connection.Open();

                try
                {
                    OleDbCommand command = new OleDbCommand("INSERT INTO [Password] ([Username], [Password]) VALUES (@username, @password)", connection);
                    command.Parameters.AddWithValue("@Username", txtusername.Text);
                    command.Parameters.AddWithValue("@Password", txtpassword.Text);
                    command.ExecuteNonQuery();
                    DialogResult result = MessageBox.Show("User is added!", "Add Account", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception)
                {
                    MessageBox.Show("User is not added", "Add Account", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                connection.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            connection.Open();
            string username = txtusername.Text;
            DialogResult dr = MessageBox.Show("Are you sure you want to delete this?", "Confirm Deletion",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                OleDbCommand com = new OleDbCommand("Delete from [Password] where @Username= " + username, connection);
                com.ExecuteNonQuery();
                MessageBox.Show("Succesfully DELETED!", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("CANCELLED!", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            connection.Close();
            loadDatagrid();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            connection.Open();
            string user = txtusername.Text;
            OleDbCommand com = new OleDbCommand("Update Username SET Password= '" + txtusername.Text + "', Password = '" + "' where username = " + user, connection);
            com.ExecuteNonQuery();
            MessageBox.Show("Succesfully UPDATED!", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            connection.Close();
            loadDatagrid();
        }
    }
}
